﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //To get input Day value
                string strDay;
                Console.Write("Enter Day: ");
                strDay = Console.ReadLine();

                //To get output Day value in number
                int k;
                Console.Write("Enter number: ");
                k = Convert.ToInt32(Console.ReadLine()); //convert string to int

                strDay = DayFrom(strDay, k);    //Calling DayFrom Function 

                Console.Write("Output is: "+ strDay);
                Console.Read();
            }
            catch (Exception e)
            {
                Console.Write("Exception in Main: " + e.Message);
                Console.Read();
            }
        }
        //Function to find the day of the week that is given days (k in int format) later
        static string DayFrom(string strDay, int k)
        {
            try
            {
                //Given day value range as per question 2
                if (k < 0 || k > 500)
                    return "Second argumnet should be from 0 to 500";

                int iDayOfWeek = 0;

                string[] strDaysOfWeek = new string[7] { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
                
                //Making UpperCase string and Comparing user input with given days 
                for (int i = 0; i < 7; i++)
                {
                    if (strDay.ToUpper() == strDaysOfWeek[i].ToUpper())
                    {
                        iDayOfWeek = i;
                        break;
                    }
                    else
                    {   //Checking if input day value does not match with designed value
                        if(i == 6)
                            return "Please enter valid day Mon or Tue or Wed or Thu or Fri or Sat or Sun";
                    }
                }
                //adding int values of input days
                int iTemp = iDayOfWeek + k;

                //if addition is more than 7 (0 to 6)
                if (iTemp > 6)
                {
                    int iTemp1 = iTemp / 7;     //Divide by 7 to get range in 7 days
                    iTemp = iTemp - (iTemp1 * 7); //deleting multiple weeks
                }

                return strDaysOfWeek[iTemp];
            }
            catch (Exception e)
            {   
                Console.Write("Exception in DayFrom Function: " + e.Message);
                Console.Read();
                return e.Message;
            }
        }
    }
}
