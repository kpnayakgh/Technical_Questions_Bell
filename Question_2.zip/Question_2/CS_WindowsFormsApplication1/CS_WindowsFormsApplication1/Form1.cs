﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using System.Net;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Runtime.Serialization;

namespace CS_WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string html = string.Empty;
            string url = @"https://capi.stage.9c9media.com/destinations/tsn_ios/platforms/iPad/contents/69585";

            //Create a WebRequest instance by calling WebRequest.Create with the URI of a resource.
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.AutomaticDecompression = DecompressionMethods.GZip; //to do the decompression

            // To get the stream containing content returned by the server. 
            // The using block ensures the stream is automatically closed.
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            //To open the stream using a StreamReader for easy access. 
            using (StreamReader reader = new StreamReader(stream))
            {
                html = reader.ReadToEnd();  // Read the content. 
            }
            //To get LastModifiedDateTime value
            int iIndex1 = html.IndexOf("LastModifiedDateTime");
            int iIndex2 = html.IndexOf("GameId");

            html =  html.Substring(iIndex1, iIndex2 - iIndex1);
                       
            MessageBox.Show(html);              

        }
    }
}
