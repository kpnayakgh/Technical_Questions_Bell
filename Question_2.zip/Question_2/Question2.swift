import UIKit

class ViewController: UIViewController 
{
    
    override func viewDidLoad() 
	{
        super.viewDidLoad()
        
		//Code to create UIButton
        let button = UIButton(type: UIButtonType.system) as UIButton
        
        let xPostion:CGFloat = 40
        let yPostion:CGFloat = 80
        let buttonWidth:CGFloat = 140
        let buttonHeight:CGFloat = 50
        
        button.frame = CGRect(x:xPostion, y:yPostion, width:buttonWidth, height:buttonHeight) //set frame
        
        button.backgroundColor = UIColor.lightGray		//Set button backgroundColor
        button.setTitle("Tap me", for: UIControlState.normal) //set button title
        button.tintColor = UIColor.black
        button.addTarget(self, action: #selector(ViewController.buttonAction(_:)), for: .touchUpInside) ////add button action
        
        self.view.addSubview(button) //add button in view
    }
    
    func buttonAction(_ sender:UIButton!)
    {
		//First we will need a URL and a session to set up the request
		guard let url = URL(string: "https://capi.stage.9c9media.com/destinations/tsn_ios/platforms/iPad/contents/69585") else {return}
		
		//Create a data task with the with URLSession
		let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
		guard let dataResponse = data,
		  error == nil else {
		  print(error?.localizedDescription ?? "Response Error")
		  return }  
		do
		{ 
		//DataResponse received from a network request 
		let jsonResponse = try JSONSerialization.jsonObject(with:
							   dataResponse, options: []) 
		print(jsonResponse) //Response result 
		
		//Now get LastModifiedDateTime value 
		guard let JasonKeyValue = jsonArray[0]["LastModifiedDateTime"] as? String else { return } 
		print(JasonKeyValue)
				
		} 
		catch let parsingError 
		{
			print("Error", parsingError) 
		}
		}
		task.resume()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
 }
